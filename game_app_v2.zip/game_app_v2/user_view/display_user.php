<!--
Rodney Dugger Dr
Stephen Platts
Alexander Underwood
Date: 2/11/2024
App Name: Game Rating App

    This is the user file.  
   -->
<?php
session_start();
require_once('../util/security.php');

//confirm user is authorized for the page
Security::checkAuthority('user');

//user clicked the logout button
if (isset($_POST['logout'])) {
    Security::logout();
}
?>
<html>
<head>
<link rel="icon" href="../admin_view/images/gri.png" type="image/png">
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Welcome To Online Gaming Rating App</title>
</head>

<body>
<div class="background-image"></div>
    <h1>Welcome To Online Gaming Rating App</h1>
    
    <h2>Please select a game you would like to rate!</h2>

    <h1>Game Selections:</h1>
    <ul>
    <li><h2><a href="display_battle_royale_user.php">
        Battle Royale</a></h2></li><?php echo "A multi player game with several gaming options to a last man standing weapon's fight to the end!"?> 
        <li><h2><a href="display_fortnite_user.php">
        Fortnite</a></h2></li><?php echo "A multi player game with great visuals and fan fair to a last man standing weapon's fight to the end!"?>
    <li><h2><a href="display_halo_user.php">
        Halo</a></h2></li><?php echo "A multi player game fight to a last man standing!"?>
    <li><h2><a href="display_games_user.php">
        Games</a></h2></li><?php echo "A list of all our games for review!"?>
    <li><h2><a href="update_password.php">
        Update Password</a></h2></li>
    <li><h2><a href="contact_info_user.php">
        Contact Info</a><h2></li>
</ul>
    
    <h2>Please enter a search for games in our database:</h2>
   <!-- jQuery library is required. -->
   <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
   <!-- Include our script file. -->
   <script type="text/javascript" src="script.js"></script>
   <!-- Include the CSS file. -->
   <link rel="stylesheet" type="text/css" href="style.css">

   <input type="text" id="games" placeholder="Search" />
    <br></br>
   <?php echo 'Search Results:'; ?>
   <!-- Suggestions will be displayed in the following div. -->
   <div id="display"></div>
   <br>
   <br/>
   <br>
   </br>

 
    <form method='POST'>
        <input type="submit" value="Logout" name="logout">
    </form>

</body>
</html>