<?php
require_once('../controller/game.php');
require_once('../controller/game_controller.php');

$games = GameController::getAllGames();
?>
<html>
<head>
<link rel="icon" href="../admin_view/images/gri.png" type="image/png">
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Available Games to rate</title>
    <link rel="stylesheet" type="text/css" href="styles.css"/>
</head>

<body>
<div class="background-image"></div>
    <h1>Available games to rate</h1>
    <h1>Available Games</h1>
    <table>
        <tr>
            <th>Game ID</th>
            <th>Game Name</th>
        </tr>
        <?php foreach ($games as $game) : ?>
        <tr>
            <td><?php echo $game->getGameNo(); ?></td>
            <td><?php echo $game->getGameName(); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <h3><a href="display_user.php">Home</a></h3>
</body>
</html>